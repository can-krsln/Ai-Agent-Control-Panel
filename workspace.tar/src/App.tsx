import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ViewMode } from './types';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import MeetingRoom from './components/MeetingRoom';
import AgentDetail from './components/AgentDetail';
import { agents } from './data/agents';

function App() {
  const [viewMode, setViewMode] = useState<ViewMode>('dashboard');
  const [selectedAgent, setSelectedAgent] = useState<string | null>(null);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const activeAgent = agents.find(a => a.id === selectedAgent);

  return (
    <div className="h-screen w-screen overflow-hidden bg-[#0a0a0f] text-white flex">
      {/* Background Effects */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-500/3 rounded-full blur-3xl" />
      </div>

      {/* Sidebar */}
      <Sidebar
        viewMode={viewMode}
        setViewMode={setViewMode}
        collapsed={sidebarCollapsed}
        setCollapsed={setSidebarCollapsed}
      />

      {/* Main Content */}
      <main className="flex-1 relative overflow-hidden">
        <AnimatePresence mode="wait">
          {viewMode === 'dashboard' && (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
              className="h-full"
            >
              <Dashboard
                agents={agents}
                onSelectAgent={(id: string) => setSelectedAgent(id)}
              />
            </motion.div>
          )}

          {viewMode === 'meeting' && (
            <motion.div
              key="meeting"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.5 }}
              className="h-full"
            >
              <MeetingRoom agents={agents} />
            </motion.div>
          )}

          {viewMode === 'agents' && (
            <motion.div
              key="agents"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.4 }}
              className="h-full"
            >
              <Dashboard agents={agents} onSelectAgent={(id: string) => setSelectedAgent(id)} showAll />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Agent Detail Panel */}
      <AnimatePresence>
        {activeAgent && (
          <AgentDetail
            agent={activeAgent}
            onClose={() => setSelectedAgent(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;
