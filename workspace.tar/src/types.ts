export interface Agent {
  id: string;
  name: string;
  role: string;
  description: string;
  status: 'active' | 'idle' | 'working' | 'offline';
  icon: string;
  color: string;
  tasks: Task[];
  uptime: string;
  lastActivity: string;
  capabilities: string[];
}

export interface Task {
  id: string;
  title: string;
  status: 'completed' | 'in-progress' | 'pending' | 'failed';
  progress: number;
  timestamp: string;
}

export interface Message {
  id: string;
  sender: string;
  content: string;
  timestamp: string;
  type: 'user' | 'agent' | 'system';
}

export type ViewMode = 'dashboard' | 'meeting' | 'agents';
