import { motion } from 'framer-motion';
import { ViewMode } from '../types';
import {
  LayoutDashboard,
  Users,
  Video,
  ChevronLeft,
  ChevronRight,
  Bot,
  Zap,
} from 'lucide-react';

interface SidebarProps {
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
}

const navItems = [
  { id: 'dashboard' as ViewMode, label: 'Kontrol Paneli', icon: LayoutDashboard },
  { id: 'meeting' as ViewMode, label: 'Toplantı Odası', icon: Video },
  { id: 'agents' as ViewMode, label: 'Agent Yönetimi', icon: Users },
];

export default function Sidebar({ viewMode, setViewMode, collapsed, setCollapsed }: SidebarProps) {
  return (
    <motion.aside
      animate={{ width: collapsed ? 72 : 240 }}
      transition={{ duration: 0.3 }}
      className="relative h-full bg-[#0d0d15]/80 border-r border-white/5 backdrop-blur-xl flex flex-col z-10"
    >
      {/* Logo */}
      <div className="p-4 flex items-center gap-3 border-b border-white/5">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center flex-shrink-0">
          <Bot className="w-6 h-6 text-white" />
        </div>
        {!collapsed && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <h1 className="text-lg font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              Agent EA
            </h1>
            <p className="text-[10px] text-gray-500 uppercase tracking-wider">Kontrol Merkezi</p>
          </motion.div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1">
        {navItems.map((item) => {
          const isActive = viewMode === item.id;
          return (
            <motion.button
              key={item.id}
              onClick={() => setViewMode(item.id)}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200 ${
                isActive
                  ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 text-cyan-400'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <item.icon className={`w-5 h-5 flex-shrink-0 ${isActive ? 'text-cyan-400' : ''}`} />
              {!collapsed && (
                <span className="text-sm font-medium">{item.label}</span>
              )}
              {isActive && !collapsed && (
                <motion.div
                  layoutId="activeIndicator"
                  className="ml-auto w-2 h-2 rounded-full bg-cyan-400"
                />
              )}
            </motion.button>
          );
        })}
      </nav>

      {/* Status */}
      {!collapsed && (
        <div className="p-4 mx-3 mb-3 rounded-xl bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/20">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-4 h-4 text-green-400" />
            <span className="text-xs font-medium text-green-400">Sistem Aktif</span>
          </div>
          <p className="text-[11px] text-gray-400">6 Agent çevrimiçi</p>
          <p className="text-[11px] text-gray-400">Tüm servisler çalışıyor</p>
        </div>
      )}

      {/* Collapse Toggle */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-[#1a1a2e] border border-white/10 flex items-center justify-center hover:bg-[#2a2a3e] transition-colors"
      >
        {collapsed ? (
          <ChevronRight className="w-3 h-3 text-gray-400" />
        ) : (
          <ChevronLeft className="w-3 h-3 text-gray-400" />
        )}
      </button>
    </motion.aside>
  );
}
