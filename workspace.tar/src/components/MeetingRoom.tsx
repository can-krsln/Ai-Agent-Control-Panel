import { useState, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Text, RoundedBox, Environment, Float } from '@react-three/drei';
import { motion } from 'framer-motion';
import { Agent, Message } from '../types';
import { meetingMessages } from '../data/agents';
import { Send, Mic, MicOff, MessageSquare, Users } from 'lucide-react';
import * as THREE from 'three';

interface MeetingRoomProps {
  agents: Agent[];
}

function Table() {
  return (
    <group position={[0, -0.5, 0]}>
      {/* Table top */}
      <mesh position={[0, 0.75, 0]}>
        <cylinderGeometry args={[2.5, 2.5, 0.1, 32]} />
        <meshStandardMaterial color="#1a1a2e" metalness={0.8} roughness={0.2} />
      </mesh>
      {/* Table leg */}
      <mesh position={[0, 0.35, 0]}>
        <cylinderGeometry args={[0.3, 0.5, 0.7, 16]} />
        <meshStandardMaterial color="#0d0d15" metalness={0.9} roughness={0.1} />
      </mesh>
      {/* Table glow ring */}
      <mesh position={[0, 0.81, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[2.2, 2.5, 64]} />
        <meshBasicMaterial color="#06b6d4" transparent opacity={0.3} />
      </mesh>
    </group>
  );
}

function Floor() {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.5, 0]}>
      <planeGeometry args={[20, 20]} />
      <meshStandardMaterial color="#080810" metalness={0.5} roughness={0.8} />
    </mesh>
  );
}

function AgentAvatar({ agent, position, isActive }: { agent: Agent; position: [number, number, number]; isActive: boolean }) {
  const meshRef = useRef<THREE.Mesh>(null);
  const glowRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * 2 + position[0]) * 0.05;
    }
    if (glowRef.current) {
      glowRef.current.scale.setScalar(1 + Math.sin(state.clock.elapsedTime * 3) * 0.1);
    }
  });

  return (
    <group position={position}>
      {/* Body */}
      <mesh ref={meshRef}>
        <capsuleGeometry args={[0.25, 0.4, 8, 16]} />
        <meshStandardMaterial
          color={agent.color}
          metalness={0.3}
          roughness={0.4}
          emissive={agent.color}
          emissiveIntensity={isActive ? 0.3 : 0.1}
        />
      </mesh>

      {/* Head */}
      <mesh position={[0, 0.55, 0]}>
        <sphereGeometry args={[0.2, 16, 16]} />
        <meshStandardMaterial
          color={agent.color}
          metalness={0.3}
          roughness={0.4}
          emissive={agent.color}
          emissiveIntensity={isActive ? 0.4 : 0.1}
        />
      </mesh>

      {/* Glow ring */}
      <mesh ref={glowRef} position={[0, -0.3, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.3, 0.4, 32]} />
        <meshBasicMaterial color={agent.color} transparent opacity={isActive ? 0.5 : 0.2} />
      </mesh>

      {/* Name label */}
      <Text
        position={[0, 1, 0]}
        fontSize={0.15}
        color="white"
        anchorX="center"
        anchorY="middle"
        font={undefined}
      >
        {agent.name}
      </Text>

      {/* Status indicator */}
      <mesh position={[0.3, 0.7, 0]}>
        <sphereGeometry args={[0.05, 8, 8]} />
        <meshBasicMaterial color={agent.status === 'working' ? '#3b82f6' : agent.status === 'active' ? '#10b981' : '#f59e0b'} />
      </mesh>
    </group>
  );
}

function UserAvatar({ position }: { position: [number, number, number] }) {
  const meshRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * 1.5) * 0.03;
    }
  });

  return (
    <group position={position}>
      <mesh ref={meshRef}>
        <capsuleGeometry args={[0.3, 0.5, 8, 16]} />
        <meshStandardMaterial color="#ffffff" metalness={0.2} roughness={0.5} emissive="#ffffff" emissiveIntensity={0.05} />
      </mesh>
      <mesh position={[0, 0.65, 0]}>
        <sphereGeometry args={[0.22, 16, 16]} />
        <meshStandardMaterial color="#ffffff" metalness={0.2} roughness={0.5} emissive="#ffffff" emissiveIntensity={0.05} />
      </mesh>
      <Text
        position={[0, 1.1, 0]}
        fontSize={0.15}
        color="#06b6d4"
        anchorX="center"
        anchorY="middle"
        font={undefined}
      >
        Siz
      </Text>
      <mesh position={[0, -0.35, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.35, 0.45, 32]} />
        <meshBasicMaterial color="#06b6d4" transparent opacity={0.4} />
      </mesh>
    </group>
  );
}

function Particles() {
  const particlesRef = useRef<THREE.Points>(null);
  const count = 200;
  const positions = new Float32Array(count * 3);

  for (let i = 0; i < count; i++) {
    positions[i * 3] = (Math.random() - 0.5) * 15;
    positions[i * 3 + 1] = Math.random() * 8;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 15;
  }

  useFrame((state) => {
    if (particlesRef.current) {
      particlesRef.current.rotation.y = state.clock.elapsedTime * 0.02;
    }
  });

  return (
    <points ref={particlesRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={positions}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial size={0.02} color="#06b6d4" transparent opacity={0.6} sizeAttenuation />
    </points>
  );
}

function Scene({ agents }: { agents: Agent[] }) {
  const radius = 3.5;
  const agentPositions: [number, number, number][] = agents.map((_, i) => {
    const angle = (i / agents.length) * Math.PI * 2 - Math.PI / 2;
    return [
      Math.cos(angle) * radius,
      0.2,
      Math.sin(angle) * radius,
    ];
  });

  const userPosition: [number, number, number] = [0, 0.2, radius + 1.5];

  return (
    <>
      <ambientLight intensity={0.2} />
      <pointLight position={[0, 5, 0]} intensity={0.5} color="#06b6d4" />
      <pointLight position={[3, 3, 3]} intensity={0.3} color="#8b5cf6" />
      <pointLight position={[-3, 3, -3]} intensity={0.3} color="#3b82f6" />
      <spotLight position={[0, 8, 0]} angle={0.5} penumbra={1} intensity={0.4} color="#ffffff" />

      <Floor />
      <Table />
      <Particles />

      <UserAvatar position={userPosition} />

      {agents.map((agent, i) => (
        <Float key={agent.id} speed={1} rotationIntensity={0} floatIntensity={0.3}>
          <AgentAvatar
            agent={agent}
            position={agentPositions[i]}
            isActive={agent.status === 'working' || agent.status === 'active'}
          />
        </Float>
      ))}

      <OrbitControls
        enablePan={false}
        minDistance={4}
        maxDistance={12}
        minPolarAngle={Math.PI / 4}
        maxPolarAngle={Math.PI / 2.2}
        autoRotate
        autoRotateSpeed={0.3}
      />
      <Environment preset="night" />
    </>
  );
}

export default function MeetingRoom({ agents }: MeetingRoomProps) {
  const [messages, setMessages] = useState<Message[]>(meetingMessages);
  const [inputValue, setInputValue] = useState('');
  const [isMuted, setIsMuted] = useState(false);

  const handleSend = () => {
    if (!inputValue.trim()) return;
    const newMsg: Message = {
      id: `m${Date.now()}`,
      sender: 'Siz',
      content: inputValue,
      timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
      type: 'user',
    };
    setMessages([...messages, newMsg]);
    setInputValue('');

    // Simulate agent response
    setTimeout(() => {
      const randomAgent = agents[Math.floor(Math.random() * agents.length)];
      const responses = [
        'Anladım, hemen üzerinde çalışmaya başlıyorum.',
        'Bu konuda bir analiz hazırlayabilirim. Biraz zaman verir misiniz?',
        'Diğer agent\'larla da konuşup kapsamlı bir rapor sunacağım.',
        'Harika bir fikir! Bunu uygulamak için birkaç adım belirledim.',
        'Bu görevi devralıyorum, sonuçları paylaşacağım.',
      ];
      const agentMsg: Message = {
        id: `m${Date.now() + 1}`,
        sender: randomAgent.name,
        content: responses[Math.floor(Math.random() * responses.length)],
        timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
        type: 'agent',
      };
      setMessages(prev => [...prev, agentMsg]);
    }, 2000);
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
            <Users className="w-4 h-4 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">Toplantı Odası</h2>
            <p className="text-xs text-gray-400">{agents.length + 1} katılımcı • Canlı</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsMuted(!isMuted)}
            className={`p-2 rounded-lg transition-colors ${isMuted ? 'bg-red-500/20 text-red-400' : 'bg-white/5 text-gray-400 hover:text-white'}`}
          >
            {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>
          <div className="px-3 py-1.5 rounded-lg bg-red-500/10 border border-red-500/20">
            <span className="text-xs text-red-400 font-medium flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              Kayıt
            </span>
          </div>
        </div>
      </div>

      {/* 3D Scene + Chat */}
      <div className="flex-1 flex overflow-hidden">
        {/* 3D Canvas */}
        <div className="flex-1 relative">
          <Canvas camera={{ position: [0, 4, 8], fov: 50 }}>
            <Scene agents={agents} />
          </Canvas>

          {/* Overlay info */}
          <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
            <div className="px-3 py-2 rounded-lg bg-black/50 backdrop-blur-sm border border-white/10">
              <p className="text-[10px] text-gray-400">🖱 Sürükle: Döndür • Scroll: Yakınlaş/Uzaklaş</p>
            </div>
            <div className="flex gap-1">
              {agents.map(agent => (
                <div
                  key={agent.id}
                  className="w-3 h-3 rounded-full border border-white/20"
                  style={{ backgroundColor: agent.color }}
                  title={agent.name}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Chat Panel */}
        <div className="w-80 border-l border-white/5 flex flex-col bg-[#0a0a12]/80">
          <div className="p-3 border-b border-white/5">
            <h3 className="text-sm font-medium text-white flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-cyan-400" />
              Toplantı Mesajları
            </h3>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex flex-col ${msg.type === 'user' ? 'items-end' : 'items-start'}`}
              >
                <span className="text-[10px] text-gray-500 mb-1 px-2">
                  {msg.sender} • {msg.timestamp}
                </span>
                <div className={`max-w-[85%] px-3 py-2 rounded-xl text-xs ${
                  msg.type === 'user'
                    ? 'bg-cyan-500/20 border border-cyan-500/30 text-cyan-100'
                    : 'bg-white/5 border border-white/10 text-gray-200'
                }`}>
                  {msg.content}
                </div>
              </motion.div>
            ))}
          </div>

          {/* Input */}
          <div className="p-3 border-t border-white/5">
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Topluluğa bir şey söyle..."
                className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50"
              />
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleSend}
                className="w-8 h-8 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-500 flex items-center justify-center"
              >
                <Send className="w-3.5 h-3.5 text-white" />
              </motion.button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
