import { motion } from 'framer-motion';
import { Agent } from '../types';
import {
  Mail,
  Search,
  Server,
  Palette,
  DollarSign,
  Monitor,
  Activity,
  Clock,
  TrendingUp,
} from 'lucide-react';

interface DashboardProps {
  agents: Agent[];
  onSelectAgent: (id: string) => void;
  showAll?: boolean;
}

const iconMap: Record<string, React.ComponentType<{ className?: string; style?: React.CSSProperties }>> = {
  mail: Mail,
  search: Search,
  server: Server,
  palette: Palette,
  dollar: DollarSign,
  monitor: Monitor,
};

const statusColors = {
  active: 'bg-green-500',
  working: 'bg-blue-500',
  idle: 'bg-yellow-500',
  offline: 'bg-gray-500',
};

const statusLabels = {
  active: 'Aktif',
  working: 'Çalışıyor',
  idle: 'Beklemede',
  offline: 'Çevrimdışı',
};

export default function Dashboard({ agents, onSelectAgent, showAll }: DashboardProps) {
  const totalTasks = agents.reduce((acc, a) => acc + a.tasks.length, 0);
  const completedTasks = agents.reduce((acc, a) => acc + a.tasks.filter(t => t.status === 'completed').length, 0);
  const activeAgents = agents.filter(a => a.status !== 'offline').length;

  return (
    <div className="h-full overflow-y-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">
            {showAll ? 'Agent Yönetimi' : 'Kontrol Paneli'}
          </h2>
          <p className="text-sm text-gray-400 mt-1">
            Tüm agent'larınızı buradan yönetin ve izleyin
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="px-3 py-1.5 rounded-lg bg-green-500/10 border border-green-500/20">
            <span className="text-xs text-green-400 font-medium">● Canlı</span>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard
          icon={Activity}
          label="Aktif Agent"
          value={`${activeAgents}/${agents.length}`}
          color="cyan"
        />
        <StatCard
          icon={TrendingUp}
          label="Toplam Görev"
          value={totalTasks.toString()}
          color="blue"
        />
        <StatCard
          icon={Clock}
          label="Tamamlanan"
          value={completedTasks.toString()}
          color="green"
        />
        <StatCard
          icon={Activity}
          label="Başarı Oranı"
          value={`%${Math.round((completedTasks / totalTasks) * 100)}`}
          color="purple"
        />
      </div>

      {/* Agent Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {agents.map((agent, index) => {
          const Icon = iconMap[agent.icon] || Monitor;
          const inProgressTasks = agent.tasks.filter(t => t.status === 'in-progress').length;

          return (
            <motion.div
              key={agent.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.02, y: -4 }}
              onClick={() => onSelectAgent(agent.id)}
              className="relative p-5 rounded-2xl bg-[#12121a]/80 border border-white/5 backdrop-blur-sm cursor-pointer group overflow-hidden"
            >
              {/* Glow effect */}
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                style={{
                  background: `radial-gradient(circle at 50% 0%, ${agent.color}15, transparent 70%)`,
                }}
              />

              <div className="relative z-10">
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-11 h-11 rounded-xl flex items-center justify-center"
                      style={{ backgroundColor: `${agent.color}20`, border: `1px solid ${agent.color}40` }}
                    >
                      <Icon className="w-5 h-5" style={{ color: agent.color }} />
                    </div>
                    <div>
                      <h3 className="font-semibold text-white text-sm">{agent.name}</h3>
                      <p className="text-[11px] text-gray-500">{agent.role}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className={`w-2 h-2 rounded-full ${statusColors[agent.status]} animate-pulse`} />
                    <span className="text-[10px] text-gray-400">{statusLabels[agent.status]}</span>
                  </div>
                </div>

                {/* Description */}
                <p className="text-xs text-gray-400 mb-4 line-clamp-2">{agent.description}</p>

                {/* Tasks Progress */}
                <div className="space-y-2">
                  {agent.tasks.slice(0, 2).map((task) => (
                    <div key={task.id} className="flex items-center gap-2">
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[11px] text-gray-300">{task.title}</span>
                          <span className="text-[10px] text-gray-500">{task.progress}%</span>
                        </div>
                        <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${task.progress}%` }}
                            transition={{ duration: 1, delay: index * 0.1 }}
                            className="h-full rounded-full"
                            style={{ backgroundColor: agent.color }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Footer */}
                <div className="flex items-center justify-between mt-4 pt-3 border-t border-white/5">
                  <span className="text-[10px] text-gray-500">
                    {inProgressTasks} aktif görev
                  </span>
                  <span className="text-[10px] text-gray-500">
                    ⏱ {agent.uptime}
                  </span>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Agent Communication */}
      <div className="p-5 rounded-2xl bg-[#12121a]/80 border border-white/5">
        <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
          <Activity className="w-4 h-4 text-purple-400" />
          Agent İletişim Ağı
        </h3>
        <div className="space-y-2">
          {[
            { from: 'Kim Agent', to: 'Atlas Agent', msg: 'Yeni mailde rakip firma hakkında bilgi var, araştırır mısın?', time: '2dk önce' },
            { from: 'Atlas Agent', to: 'Nexus Agent', msg: 'Araştırma raporu hazır, sunucuya yükleyebilir misin?', time: '5dk önce' },
            { from: 'Nexus Agent', to: 'Pixel Agent', msg: 'Rapor için görsel hazırlaman gerekiyor, detaylar ekte.', time: '8dk önce' },
            { from: 'Phantom Agent', to: 'Ledger Agent', msg: 'Uzak masaüstünde fatura dosyaları güncellendi.', time: '12dk önce' },
          ].map((comm, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              className="flex items-center gap-3 p-3 rounded-xl bg-white/[0.02] border border-white/5"
            >
              <span className="text-[11px] font-medium text-cyan-400 min-w-[80px]">{comm.from}</span>
              <div className="flex items-center gap-1">
                <div className="w-4 h-px bg-gradient-to-r from-cyan-500 to-purple-500" />
                <span className="text-[10px] text-gray-500">→</span>
                <div className="w-4 h-px bg-gradient-to-r from-purple-500 to-pink-500" />
              </div>
              <span className="text-[11px] font-medium text-purple-400 min-w-[80px]">{comm.to}</span>
              <span className="flex-1 text-[11px] text-gray-400 truncate">{comm.msg}</span>
              <span className="text-[10px] text-gray-600">{comm.time}</span>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Activity Timeline */}
      <div className="mt-6 p-5 rounded-2xl bg-[#12121a]/80 border border-white/5">
        <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
          <Activity className="w-4 h-4 text-cyan-400" />
          Son Aktiviteler
        </h3>
        <div className="space-y-3">
          {agents.flatMap(agent =>
            agent.tasks
              .filter(t => t.status === 'in-progress' || t.status === 'completed')
              .map(task => ({ ...task, agentName: agent.name, agentColor: agent.color }))
          ).slice(0, 6).map((task, i) => (
            <motion.div
              key={task.id + i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05 }}
              className="flex items-center gap-3"
            >
              <div className="w-2 h-2 rounded-full" style={{ backgroundColor: task.agentColor }} />
              <div className="flex-1 flex items-center justify-between">
                <div>
                  <span className="text-xs text-white">{task.title}</span>
                  <span className="text-[10px] text-gray-500 ml-2">— {task.agentName}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                    task.status === 'completed' ? 'bg-green-500/10 text-green-400' : 'bg-blue-500/10 text-blue-400'
                  }`}>
                    {task.status === 'completed' ? 'Tamamlandı' : 'Devam ediyor'}
                  </span>
                  <span className="text-[10px] text-gray-500">{task.timestamp}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string; color: string }) {
  const colorClasses: Record<string, string> = {
    cyan: 'from-cyan-500/10 to-cyan-500/5 border-cyan-500/20 text-cyan-400',
    blue: 'from-blue-500/10 to-blue-500/5 border-blue-500/20 text-blue-400',
    green: 'from-green-500/10 to-green-500/5 border-green-500/20 text-green-400',
    purple: 'from-purple-500/10 to-purple-500/5 border-purple-500/20 text-purple-400',
  };

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className={`p-4 rounded-xl bg-gradient-to-br ${colorClasses[color]} border backdrop-blur-sm`}
    >
      <Icon className="w-5 h-5 mb-2 opacity-70" />
      <p className="text-2xl font-bold text-white">{value}</p>
      <p className="text-xs text-gray-400 mt-1">{label}</p>
    </motion.div>
  );
}
