import { motion } from 'framer-motion';
import { Agent } from '../types';
import {
  X,
  Mail,
  Search,
  Server,
  Palette,
  DollarSign,
  Monitor,
  Clock,
  Zap,
  CheckCircle,
  AlertCircle,
  Loader,
  Play,
  Pause,
  Settings,
  Terminal,
} from 'lucide-react';
import { useState } from 'react';

interface AgentDetailProps {
  agent: Agent;
  onClose: () => void;
}

const iconMap: Record<string, React.ComponentType<{ className?: string; style?: React.CSSProperties }>> = {
  mail: Mail,
  search: Search,
  server: Server,
  palette: Palette,
  dollar: DollarSign,
  monitor: Monitor,
};

const statusConfig = {
  active: { label: 'Aktif', color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/20' },
  working: { label: 'Çalışıyor', color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/20' },
  idle: { label: 'Beklemede', color: 'text-yellow-400', bg: 'bg-yellow-500/10', border: 'border-yellow-500/20' },
  offline: { label: 'Çevrimdışı', color: 'text-gray-400', bg: 'bg-gray-500/10', border: 'border-gray-500/20' },
};

export default function AgentDetail({ agent, onClose }: AgentDetailProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'tasks' | 'logs'>('overview');
  const Icon = iconMap[agent.icon] || Monitor;
  const status = statusConfig[agent.status];

  return (
    <motion.div
      initial={{ x: 400, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: 400, opacity: 0 }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="absolute right-0 top-0 bottom-0 w-[420px] bg-[#0d0d18]/95 border-l border-white/5 backdrop-blur-xl z-50 flex flex-col overflow-hidden"
    >
      {/* Header */}
      <div className="p-5 border-b border-white/5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{ backgroundColor: `${agent.color}20`, border: `1px solid ${agent.color}40` }}
            >
              <Icon className="w-6 h-6" style={{ color: agent.color }} />
            </div>
            <div>
              <h3 className="font-bold text-white">{agent.name}</h3>
              <p className="text-xs text-gray-400">{agent.role}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors"
          >
            <X className="w-4 h-4 text-gray-400" />
          </button>
        </div>

        {/* Status & Controls */}
        <div className="flex items-center justify-between">
          <div className={`px-3 py-1.5 rounded-lg ${status.bg} border ${status.border}`}>
            <span className={`text-xs font-medium ${status.color}`}>● {status.label}</span>
          </div>
          <div className="flex items-center gap-1">
            <button className="w-7 h-7 rounded-lg bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors">
              <Play className="w-3 h-3 text-green-400" />
            </button>
            <button className="w-7 h-7 rounded-lg bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors">
              <Pause className="w-3 h-3 text-yellow-400" />
            </button>
            <button className="w-7 h-7 rounded-lg bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors">
              <Settings className="w-3 h-3 text-gray-400" />
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-white/5">
        {(['overview', 'tasks', 'logs'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-3 text-xs font-medium transition-colors ${
              activeTab === tab
                ? 'text-cyan-400 border-b-2 border-cyan-400'
                : 'text-gray-500 hover:text-gray-300'
            }`}
          >
            {tab === 'overview' ? 'Genel' : tab === 'tasks' ? 'Görevler' : 'Loglar'}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-5 space-y-4">
        {activeTab === 'overview' && (
          <>
            {/* Description */}
            <div className="p-4 rounded-xl bg-white/5 border border-white/5">
              <p className="text-xs text-gray-300 leading-relaxed">{agent.description}</p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                <Clock className="w-4 h-4 text-cyan-400 mb-2" />
                <p className="text-lg font-bold text-white">{agent.uptime}</p>
                <p className="text-[10px] text-gray-500">Çalışma Süresi</p>
              </div>
              <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                <Zap className="w-4 h-4 text-yellow-400 mb-2" />
                <p className="text-lg font-bold text-white">{agent.tasks.length}</p>
                <p className="text-[10px] text-gray-500">Toplam Görev</p>
              </div>
            </div>

            {/* Capabilities */}
            <div>
              <h4 className="text-xs font-medium text-gray-400 mb-2 uppercase tracking-wider">Yetenekler</h4>
              <div className="flex flex-wrap gap-2">
                {agent.capabilities.map((cap) => (
                  <span
                    key={cap}
                    className="px-2.5 py-1 rounded-lg text-[10px] font-medium bg-white/5 border border-white/10 text-gray-300"
                  >
                    {cap}
                  </span>
                ))}
              </div>
            </div>

            {/* Connection Status */}
            <div className="p-4 rounded-xl bg-gradient-to-br from-green-500/5 to-emerald-500/5 border border-green-500/10">
              <h4 className="text-xs font-medium text-green-400 mb-2">Bağlantı Durumu</h4>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-gray-400">Uzak Bağlantı</span>
                  <span className="text-[11px] text-green-400">● Bağlı</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-gray-400">Gecikme</span>
                  <span className="text-[11px] text-white">12ms</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-gray-400">Son Aktivite</span>
                  <span className="text-[11px] text-white">{agent.lastActivity}</span>
                </div>
              </div>
            </div>
          </>
        )}

        {activeTab === 'tasks' && (
          <div className="space-y-3">
            {agent.tasks.map((task, i) => (
              <motion.div
                key={task.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="p-4 rounded-xl bg-white/5 border border-white/5"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium text-white">{task.title}</span>
                  {task.status === 'completed' && <CheckCircle className="w-4 h-4 text-green-400" />}
                  {task.status === 'in-progress' && <Loader className="w-4 h-4 text-blue-400 animate-spin" />}
                  {task.status === 'pending' && <AlertCircle className="w-4 h-4 text-yellow-400" />}
                  {task.status === 'failed' && <AlertCircle className="w-4 h-4 text-red-400" />}
                </div>
                <div className="h-1.5 rounded-full bg-white/5 overflow-hidden mb-2">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${task.progress}%` }}
                    transition={{ duration: 0.8, delay: i * 0.1 }}
                    className="h-full rounded-full"
                    style={{ backgroundColor: agent.color }}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-gray-500">{task.progress}% tamamlandı</span>
                  <span className="text-[10px] text-gray-500">{task.timestamp}</span>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {activeTab === 'logs' && (
          <div className="space-y-2 font-mono">
            <div className="flex items-center gap-2 mb-3">
              <Terminal className="w-4 h-4 text-cyan-400" />
              <span className="text-xs text-cyan-400">Agent Logları</span>
            </div>
            {[
              { time: '10:45:23', level: 'INFO', msg: 'Görev başlatıldı: Veri senkronizasyonu' },
              { time: '10:44:12', level: 'INFO', msg: 'API bağlantısı başarılı' },
              { time: '10:43:55', level: 'WARN', msg: 'Yanıt süresi yüksek: 2.3s' },
              { time: '10:42:30', level: 'INFO', msg: 'Yeni görev kuyruğa alındı' },
              { time: '10:41:18', level: 'INFO', msg: 'Önceki görev tamamlandı' },
              { time: '10:40:05', level: 'ERROR', msg: 'Geçici bağlantı hatası - Yeniden deneme başarılı' },
              { time: '10:39:44', level: 'INFO', msg: 'Agent başlatıldı' },
              { time: '10:39:40', level: 'INFO', msg: 'Sistem kontrolü tamamlandı' },
            ].map((log, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05 }}
                className="flex items-start gap-2 text-[11px]"
              >
                <span className="text-gray-600">{log.time}</span>
                <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                  log.level === 'INFO' ? 'bg-blue-500/10 text-blue-400' :
                  log.level === 'WARN' ? 'bg-yellow-500/10 text-yellow-400' :
                  'bg-red-500/10 text-red-400'
                }`}>{log.level}</span>
                <span className="text-gray-400">{log.msg}</span>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Footer Actions */}
      <div className="p-4 border-t border-white/5 flex items-center gap-2">
        <button className="flex-1 py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-500 text-xs font-medium text-white hover:opacity-90 transition-opacity">
          Yeni Görev Ata
        </button>
        <button className="py-2 px-3 rounded-lg bg-white/5 border border-white/10 text-xs text-gray-400 hover:text-white transition-colors">
          API Ayarları
        </button>
      </div>
    </motion.div>
  );
}
